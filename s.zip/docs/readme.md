#Documentation

A good starting point is our [gentle introduction to the lightning network](https://github.com/yoursnetwork/yours-channels/blob/master/docs/gentle-lightning.md). We also have a [prospectus system description](https://github.com/yoursnetwork/yours-channels/blob/master/docs/yours-lightning.md) that we are trying to keep more or less in sync with the [implementation](https://github.com/yoursnetwork/yours-channels/blob/master/lib/agent). Note that everything here is a work in progress and subject to change.
